#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

void app_main() {
  gpio_set_direction(2,GPIO_MODE_OUTPUT);
  gpio_set_level(2,1);
  printf("eloa \n");
  while (true) {
     gpio_set_level(2,1);
      gpio_set_level(2,0);
  printf("16 anos\n");
   vTaskDelay (1000 / portTICK_PERIOD_MS);
    gpio_set_level(2,1);
   printf("itapevi\n");
   vTaskDelay (1000 / portTICK_PERIOD_MS);
  }
}
